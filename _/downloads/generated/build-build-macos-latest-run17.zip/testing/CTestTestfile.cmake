# CMake generated Testfile for 
# Source directory: /Users/runner/work/smartse-template/smartse-template/testing
# Build directory: /Users/runner/work/smartse-template/smartse-template/build/testing
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
